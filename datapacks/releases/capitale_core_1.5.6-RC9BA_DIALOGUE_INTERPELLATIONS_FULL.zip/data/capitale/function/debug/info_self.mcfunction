function capitale:player/ensure_runtime_self
function capitale:debug/inforp/ensure_self
function capitale:debug/journal/count_active_self
function capitale:dialogue/sound/parole_simple_self
tellraw @s {"text":"──────── Dossier RP de la Capitale ────────","color":"gold","bold":true}
tellraw @s {"text":"— Identité et statut","color":"yellow"}
function capitale:debug/inforp/rang_self
function capitale:debug/inforp/crime_public_self
function capitale:debug/inforp/etat_self
tellraw @s {"text":"— Justice et procédures","color":"yellow"}
function capitale:debug/inforp/justice_self
tellraw @s {"text":"— Réputations notables","color":"yellow"}
function capitale:debug/inforp/reputations_self
tellraw @s {"text":"— Quêtes et objectifs","color":"yellow"}
function capitale:debug/journal/summary_inforp_self
tellraw @s {"text":"— Actions rapides","color":"yellow"}
tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Journal","color":"gold","click_event":{"action":"run_command","command":"/trigger InfoRP set 2"},"hover_event":{"action":"show_text","value":"Ouvrir le journal de quêtes."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Quêtes actives","color":"yellow","click_event":{"action":"run_command","command":"/trigger InfoRP set 3"},"hover_event":{"action":"show_text","value":"Voir les objectifs actuellement actifs."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Progression","color":"aqua","click_event":{"action":"run_command","command":"/trigger InfoRP set 4"},"hover_event":{"action":"show_text","value":"Voir la progression des suites et catégories découvertes."}},{"text":"]","color":"dark_gray"}]
tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Profils / personnages","color":"dark_aqua","click_event":{"action":"run_command","command":"/trigger InfoRP set 20"},"hover_event":{"action":"show_text","value":"Ouvrir le registre RP des personnages et les hooks prévus pour le futur mod."}},{"text":"]","color":"dark_gray"}]
tellraw @s {"text":"— Détails","color":"yellow"}
tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Identité","color":"green","click_event":{"action":"run_command","command":"/trigger InfoRP set 5"},"hover_event":{"action":"show_text","value":"Rang, statut légal, état, mission actuelle."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Justice","color":"red","click_event":{"action":"run_command","command":"/trigger InfoRP set 6"},"hover_event":{"action":"show_text","value":"Crime détaillé, amendes, comparution et laissez-passer judiciaire."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Réputations","color":"light_purple","click_event":{"action":"run_command","command":"/trigger InfoRP set 7"},"hover_event":{"action":"show_text","value":"Voir les réputations non neutres."}},{"text":"]","color":"dark_gray"}]
tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Accès","color":"green","click_event":{"action":"run_command","command":"/trigger InfoRP set 8"},"hover_event":{"action":"show_text","value":"Accès permanents et passages temporaires."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Guidage","color":"aqua","click_event":{"action":"run_command","command":"/trigger InfoRP set 9"},"hover_event":{"action":"show_text","value":"État des escortes et verrouillages de guidage."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Plans","color":"dark_purple","click_event":{"action":"run_command","command":"/trigger InfoRP set 10"},"hover_event":{"action":"show_text","value":"Rappel RP des plans et portails."}},{"text":"] ","color":"dark_gray"},{"text":"[","color":"dark_gray"},{"text":"Aide","color":"gray","click_event":{"action":"run_command","command":"/trigger InfoRP set 11"},"hover_event":{"action":"show_text","value":"Liste lisible des triggers InfoRP disponibles."}},{"text":"]","color":"dark_gray"}]
