execute if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1] run tp @s @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1]
execute if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1] run scoreboard players set @s NPC_PATROL_STATE 12
execute if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1] run scoreboard players set @s NPC_PATROL_DIR 1
execute unless entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1] if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_o,limit=1] run tp @s @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_o,limit=1]
execute unless entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1] if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_o,limit=1] run scoreboard players set @s NPC_PATROL_STATE 14
execute unless entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_m,limit=1] if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_01_o,limit=1] run scoreboard players set @s NPC_PATROL_DIR 0
scoreboard players set @s NPC_PATROL_CD 40
