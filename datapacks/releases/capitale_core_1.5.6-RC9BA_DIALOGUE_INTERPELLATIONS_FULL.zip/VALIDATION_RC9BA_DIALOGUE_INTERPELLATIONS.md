# capitale_core 1.5.6-RC9BA — interpellations caméra sélectives

Base stricte : RC9AY FULL consolidé.

Cette version ajoute uniquement cinq appels opt-in au mod `haute_capitale_dialogue` b9 :
- Géraud Rivet — démarrage du prologue ;
- Althéon Brumeforge — interception capitaine du prologue ;
- Léovic — offre de quête au Port ;
- Aurèle Veyrane — interception à la sortie de l'ascenseur du Cœur ;
- Roch Vallet — interception au second ascenseur / Profondeurs.

Commande utilisée :
`hcd_interpellation nearest_named <nom>`

Aucun hook n'est ajouté aux bavardages `near` ordinaires, rappels d'escorte ou lignes d'ambiance.
Les contrôles d'accès avec « suivre le garde » / « tenter un arrangement » sont détectés par le
client b9 via leur `CapChoix` et ne nécessitent donc aucune modification aveugle des fonctions
d'accès non présentes dans le Core fourni.

Aucune logique de quête existante, score, tellraw, TP, créature, Orc, biome, feu ou EasyNPC n'est
supprimée ou modifiée.
