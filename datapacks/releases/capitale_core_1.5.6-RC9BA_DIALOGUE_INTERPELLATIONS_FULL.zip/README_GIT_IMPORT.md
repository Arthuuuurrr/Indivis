# Snapshot Git — capitale_core

Source canonique consolidée : **capitale_core 1.5.6-RC9AY**.

RC9AY reprend intégralement RC9AX et restaure les 10 fonctions historiques qui étaient encore
référencées par les menus/ticks d'administration mais avaient disparu lors de la transition vers RC9AS.

Consolidation incluse :
- bootstrap prologue/Nexus RC9AX ;
- base fonctionnelle RC9AU et biomes urbains ;
- restauration de `indivis:corruption` ;
- interactions Adventure RC9AT pour les objets Cube Animals cassables ;
- optimisation PERF1 du raycast feu ;
- Aubecourt, Sylvharen et tous les biomes urbains RC9AU ;
- fonctions debug `info_self` / `values_self` ;
- fonctions de visualisation/effacement des waypoints d'escorte Colin, Roch, Léovic et Aurèle.

Aucune fonction ou ressource `data/` présente dans les datapacks de référence fournis n'est absente
de RC9AY.
