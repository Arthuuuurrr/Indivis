execute if entity @e[type=marker,tag=wp_gardeprofondeurs_patrol_07_a,limit=1] run tp @s @e[type=marker,tag=wp_gardeprofondeurs_patrol_07_a,limit=1]
scoreboard players set @s NPC_PATROL_STATE 0
scoreboard players set @s NPC_PATROL_CD 40
