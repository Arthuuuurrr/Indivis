Installation PQ04/PQ05-R1

Ouvrir documentation/INSTALLATION_PQ04_PQ05_R1.md.

Remplacer les deux datapacks serveur et le JAR Quêtes serveur/clients, redémarrer, puis effectuer les liaisons et la mémorisation des 39 repères existants.

Le protocole et les limites de validation figurent dans les documents joints.
