# Dépendances — PQ04/PQ05-R1

Le core de référence est le HF1/PQ03 transmis ; les empreintes des trois archives d'entrée figurent dans `preuves/manifest.json`. Les archives originales restent inchangées.

| Fichier inspecté | Mod ID | Version déclarée | SHA-256 |
|---|---|---|---|
| `NexusCharacters-Indivis-1.21.11-PRE35-SI1-OPT3(1).jar` | `nexuscharacters` | `1.0.0-beta.35+indivis.1.21.11.SI1.OPT3` | `de06ecab0f5cf7ccee29043bff2ccb5fd2b7425c173da145c1f27559b49def7b` |
| `capitale_currency_BETA_1_0_hotfix5_bourse50_stack99_legacy_style_1_21_11.jar` | `capitale_currency` | `1.0.0-beta.5+bourse50_stack99_legacy_style_fix` | `a0158a061a5c5fbb2befcb1de5201198066db41ddf8a94f4b099dc115a7fad34` |
| `easy_npc-fabric-1.21.11-7.16.0(1).jar` | `easy_npc` | `7.16.0` | `be3531fba0d3b0553e64ac8acae1906a882f41b32ac5e64386c3d6c4cbef6f8b` |
| `easy_npc_config_ui-fabric-1.21.11-7.16.0(1).jar` | `easy_npc_config_ui` | `7.16.0` | `c65b5eff3f9ac46a3de3572d2b32f7f64b00731c6ad22e02a379b8634606b774` |
| `haute-capitale-dialogue-0.1.0+1.21.11.b10-DATAPACK-COMMAND-HOTFIX(1).jar` | `haute_capitale_dialogue` | `0.1.0+1.21.11.b10` | `a2c21f24889f96880c472d168ea55cf65e84ff154ee1bbcc22dbeaa9df1d4057` |
| `puffish_skills-0.17.3-1.21.11-fabric (1).jar` | `puffish_skills` | `0.17.3` | `c32ee10b9883e7fdd2ae3a70cb00530a7c230c54a5c07a87a448353390c9066d` |

Le JAR Haute Capitale Quêtes conserve son identifiant, ses dépendances et ses anciens entrypoints ; l'extension PQ04/PQ05 est ajoutée au JAR existant pour la visibilité privée et la caméra de dialogue. Aucun nouveau mod autonome n'est installé. Les six JAR ci-dessus doivent être fournis dans `tools/pq0405/dependencies/` pour reconstruire les bancs ; ils ne sont pas redistribués dans l'archive de sources.

Le runtime de validation utilise Minecraft 1.21.11, Fabric Loader 0.19.5, Fabric API 0.141.6+1.21.11 et Java 21. Les URLs officielles et les empreintes des téléchargements utilisés figurent dans `preuves/runtime_dependencies.json`. `prepare_runtime.py` télécharge ces versions, valide le SHA-1 officiel de Minecraft et enregistre les SHA-256 locaux des autres dépendances.

Le HUD transmis est conservé sans modification. Son rendu graphique et le journal dans la vraie carte n'ont pas été essayés. Le test natif emploie de vrais JAR EasyNPC, Dialogue et monnaie ; la sélection Nexus et les connexions sont synthétiques. Le DTO, le writer/loader et la politique de persistance Nexus sont réels. RPG/Puffish et les gains CapSkills/bonus utilisent des substituts déclarés dans `preuves/native_fixture.json`.

L'API Nexus inspectée déclare human, dwarf, wood_elf, high_elf, nordic et villager. Elle ne fournit pas de race Orc persistante : aucune variante Orc ni conversion de villager n'est ajoutée. Une race inconnue conserve le texte commun.
