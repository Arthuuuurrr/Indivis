# Rapport de livraison — PQ04/PQ05-R1 — 09/11/2026

## Base et périmètre

Intégration effectuée sur une **copie** des archives HF1/PQ03 transmises, après lecture du prompt complet du 09/11/2026. Les trois fichiers d'entrée restent inchangés ; leurs SHA-256 figurent dans `preuves/manifest.json` et `preuves/static.json`.

| Archive | Entrées modifiées | Entrées ajoutées | Entrées inchangées |
|---|---:|---:|---:|
| core | 173 | 20 | 11180 |
| quests | 3 | 0 | 3327 |
| mod | 4 | 30 | 288 |

Aucune entrée n'est supprimée. Dans `hc_quetes`, seules les fiches JSON PQ04 et PQ05 et la description de version changent : les fonctions de Clément, les identifiants de quêtes et les autres contenus de la fusion C1 sont conservés.

## PQ04

- Intégration des rencontres de Roch et Colin, des sous-branches de Roch, des questions facultatives, des réactions sur les habitants et des conclusions. Les blocs successifs d'un même PNJ sont regroupés ; leur lecture reste contrôlée par le joueur.
- Roch utilise A–M, propose la caisse à H et reste **en haut** du second ascenseur. Le joueur descend seul. Colin démarre à sa source du poste inférieur, puis suit A–Z. Aucun dialogue Roch/Colin ni téléportation entre ces étages n'est ajouté.
- Colin s'arrête aux pauses D et H déjà prévues et propose le commentaire extérieur à X. Le choix de X réutilise un repère existant ; son adéquation au décor réel doit être contrôlée sur la carte.
- Navigation EasyNPC réelle, vitesse de navigation 1,2 avec attribut de base 0,25 comme les escortes privées déjà en place. Les points ordinaires s'enchaînent ; les recherches de chemin et attentes sont bornées. Un joueur éloigné entraîne une attente ; un tronçon non chargé n'est pas franchi par téléportation.
- Les retours s'effectuent à rebours sur les parcours. Un retour de Roch peut coexister avec la scène de Colin ; il est suspendu pendant la conversation. Les guides publics ne sont pas déplacés par le nouveau moteur.
- Suppression du +5 automatique de Colin et du −3 de refus de caisse. Remise : +25 Martins, **+1** Gardes, +1 souvenir Colin. Refus méprisant : −1 Gardes et −1 Roch ; autres refus neutres. Remerciement à Roch : +1 Gardes/+1 Roch. Remerciement à Colin et défense des habitants : souvenir seulement. Réaction méprisante envers Colin : −1 Gardes/−1 Colin.
- Le bonus aléatoire des Profondeurs et les fonctions historiques de compétence/XP sont conservés **sur la remise effective de caisse**, une seule fois. Ils n'ajoutent pas les anciens bonus de réputation. Aucun gain de compétence supplémentaire n'est ajouté pour une escorte sans livraison.

## PQ05

L'aubergiste est disponible avant le magistrat. Location : vingt Martins, reconnaissance d'une chambre déjà payée, hébergement déclaré sans titre de propriété. Ensuite, présentation au magistrat et frais uniques de cent Martins. Les critiques des prix ou de l'Empire restent neutres.

L'inscription porte le rang à 20 uniquement s'il est inférieur, recalcule les accès et le préfixe existants, termine PQ05 et règle `QUEST_PROLOGUE` à 100. Le +3 automatique de `REP_PROFONDEURS` est retiré. Le marqueur « ! » passe de l'aubergiste au magistrat après la chambre ; les objectifs du journal suivent le même ordre.

Les **sept fonctions de citoyenneté** sont conservées octet pour octet. La proposition distincte est déclenchée une seule fois depuis l'état canonique initial ; ses frais de 500 Martins ne sont jamais prélevés par PQ05. L'ancien routeur du magistrat est conservé sous `legacy_interact_self` pour les interactions de citoyenneté déjà engagées.

## Isolation, sauvegarde et migrations

Chaque acteur reçoit un UUID aléatoire et des tags de propriétaire et de personnage Nexus. Le suivi de visibilité filtre les paquets par les deux identités, et masque le PNJ public uniquement à son propriétaire de scène. Les choix utilisent un jeton de page ; un ancien jeton ne peut pas rejouer une récompense. Les actions, la mémoire et les frais sont enregistrés dans les scores `CAP_` déjà persistés par Nexus.

Les positions privées sont stockées par personnage dans `capitale:pq45_scene/<UUID>`, avec contrôle du propriétaire, de la phase, du waypoint et de la dimension. La configuration globale `capitale:pq45_setup` ne contient que les sources et repères communs. Les états canoniques `hcq_pq04`/`hcq_pq05` sont conservés et écrits via les fonctions de migration existantes.

Les nouveaux champs couvrent version de migration, pages par PNJ, points par guide, décisions uniques, caisse, souvenirs, pauses D/H/X et paiements. La liste exacte est dans `Pq45Rules.SCORES`. Les jetons/UI temporaires n'ajoutent pas de nouvelles données persistantes de compte. Les snapshots Nexus périodiques conservent la scène active ; une vraie sortie de personnage ferme et nettoie sa scène. Le rechargement et le redémarrage restaurent le parcours sans reprendre une récompense.

Les anciennes caisses sans propriétaire restent acceptées seulement pour un personnage dont l'état historique indique une caisse en cours. **Le propriétaire d'un ancien item non marqué ne peut pas être prouvé rétrospectivement.** Les nouvelles caisses, elles, sont liées au compte et au personnage ; perte d'item et inventaire plein n'accordent pas de caisse gratuite ou de récompense en double.

Les anciens états déjà terminés, réputations acquises, chambres payées et rangs supérieurs sont préservés. Les vieux refus de caisse qui n'avaient aucun état individuel ne peuvent pas être reconstitués avec certitude ; cette limite concerne la première migration, pas les décisions nouvelles.

## Pourquoi le JAR est nécessaire

Le datapack seul ne possède pas le protocole de visibilité et de caméra requis pour ajouter deux guides propriétaires. Le JAR existant est donc étendu, **sans nouveau mod séparé**, sans changement de Nexus ou du HUD. Les dépendances et les anciens entrypoints sont identiques.

Deux classes historiques seulement changent : `Pq02ProfileCheckpoint` ajoute la délégation PQ04/PQ05 tout en conservant les cas PQ02/PQ03 ; `QuestReputationNotice` accepte les notifications Gardes des Profondeurs et monnaie. La table existante des donneurs de quête est complétée pour l'aubergiste. Tous les autres bytecodes historiques sont identiques. Les nouveaux mixins sont réellement annotés `@Mixin`, compilés pour Java 21 et chargés par Fabric dans le banc serveur.

## Préservation vérifiée

Les répertoires PQ01, PQ02, PQ03 et leurs scénarios de core sont identiques octet pour octet, ainsi que les sept fonctions de citoyenneté et les **45 fichiers de pose/debug** des parcours de Roch et Colin. Les fonctions MQ01–MQ03 du pack de Clément et les interactions du capitaine Althéon/Archives ne sont pas réécrites. Le rapport différentiel complet énumère tous les chemins modifiés et ajoutés ; aucun autre contenu n'est remplacé par un ancien pack.

Le retrait des quatre appels de tick partagés Roch/Colin empêche le fonctionnement simultané des anciens guides à UUID fixe et du nouveau moteur. Les anciens points d'entrée restent présents sous forme de routes compatibles ; les pilotes partagés et resets globaux ne peuvent plus téléporter un PNJ public ou attribuer la progression au joueur le plus proche.

## Résultats réellement obtenus

| Banc | Résultat |
|---|---|
| Statique/différentiel | PASS : 701 contrôles, 963 JSON/mcmeta, 13704 fonctions indexées, aucune nouvelle référence interne introuvable |
| serveur | PASS 1260 native checks |
| redemarrage | PASS 13 restart checks |
| protocole_pq02 | PASS 566 real client protocol checks; native b10 state and actual Fabric events, graphical client/world/screen and C2S recorder doubled |
| protocole_pq03 | PASS 302 real client protocol checks; native b10 state and actual Fabric events, graphical client/world/screen and C2S recorder doubled |
| protocole_pq04_pq05 | PASS 572 real client protocol checks; native b10 state and actual Fabric events, graphical client/world/screen and C2S recorder doubled |

Le contrôle de reprise du 10/11/2026 a reconstruit les trois fichiers depuis le ZIP de sources extrait dans un dossier distinct, avec les archives d’entrée et les dépendances déjà disponibles : leurs SHA-256 sont identiques aux fichiers testés. Le contrôle statique a également été relancé avec succès. Ce contrôle ne constitue pas un nouveau passage de tests en jeu. La preuve est dans `preuves/delivery_rebuild.json`.

Le serveur est un vrai Minecraft **1.21.11**, sous Fabric **0.19.5**, avec les JAR de production Quêtes, Dialogue b10, EasyNPC 7.16.0 et monnaie. Le monde plat et les connexions sont synthétiques. Le DTO, le writer/loader et la politique de persistance Nexus PRE35 sont réels, mais sa sélection de personnage est pilotée par le banc.

Les tests natifs couvrent notamment deux escortes simultanées A–M/A–Z, toutes les pages, les réponses à effet social, les seuils monétaires, l'idempotence, les caisses nouvelles et historiques, l'inventaire plein, les marqueurs « ! », ESC, l'éloignement, un objectif de navigation non chargé, la reprise, les snapshots y compris non-OP, le changement A–B–A, un vrai `/reload`, puis un **second processus Java** rouvrant le même monde.

Les tests de protocole utilisent les vrais événements Fabric et le vrai `DialogueClientState`/`MessageCapture` b10, avec un écran et un monde client sans rendu. Les suites PQ02 et PQ03 sont exécutées avec le nouveau listener présent. Cela vérifie les textes, choix, locuteurs, confirmations de capture, fermeture ESC et notifications ; cela ne constitue pas un essai graphique du HUD.

Les intégrations CapSkills/XP et bonus aléatoires sont comptées par des substituts de fonctions ; les implémentations RPG/Puffish sont déclarées par des fixtures, et ne constituent pas des essais réels de ces systèmes. Les objets monnaie du banc sont les vrais Martins du JAR de dépendance récupéré.

## Limites et recette restante

- Aucun vrai client graphique ni la carte Indivis n'a été utilisé : pas de validation visuelle des ascenseurs, obstacles, cadrages, skins, journal/HUD, ni de mesure de FPS. Les interactions en jeu doivent suivre le plan de recette joint.
- Le Nexus audité n'expose pas d'Orc persistant. Les variantes humaines, elfes (deux IDs), naines et nordiques sont codées ; race inconnue et Villageois reçoivent le texte commun. Réputation, actes et criminalité priment. Aucune assimilation inventée ni modification de Nexus n'est livrée.
- Les seuils sociaux reprennent le core : criminalité 10, réputation prudente ≤−40, favorable ≥10. Les souvenirs sont propres au personnage. Le magistrat reste administratif et les prix 20/100/500 sont inchangés pour toutes les races.
- Deux références internes candidates préexistantes sont signalées par le scanner : une ancienne aide d'administration et une route de pose dynamique. Elles n'ont pas été introduites ni corrigées dans ce mandat ; le détail est dans `static.json`.
- Les journaux de banc contiennent l'échec réseau de récupération des clés Yggdrasil dans l'environnement de test hors ligne. Aucun échec de chargement de fonction ou de mixin n'est présent dans les derniers passages réussis.

## Empreintes de livraison

| Fichier | SHA-256 |
|---|---|
| `capitale_core_1.5.7_PQ04_PQ05_R1_20261109.zip` | `d46689fdd6fd20507bf6d902b1fb4532cd916fa045f9f20a1a7f19e257265185` |
| `hc_quetes_FUSION_C1_PQ04_PQ05_R1_20261109.zip` | `cbbaf9d81a32b9334ceafaaed08db66871e67966709cdc2d12b41247a7426afe` |
| `haute-capitale-quetes-PQ04-PQ05-R1-1.21.11.jar` | `f75eab9c6113d131480398109a2d17c31298ad7677d6ebe4dcca833d7ca53ccf` |

Sources, scripts, graphes, différences détaillées et protocole de recette sont fournis avec la livraison. Les journaux distribués sont ceux du monde synthétique ; aucun log réel du serveur utilisateur n'est publié.
