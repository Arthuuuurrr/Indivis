# Installation — PQ04/PQ05-R1 — 09/11/2026

Minecraft **1.21.11**, Fabric Loader **0.19.5 ou compatible**, Fabric API **0.141.6+1.21.11**, Java **21**. Garder les dépendances actuellement installées : EasyNPC **7.16.0**, Dialogue **b10 DATAPACK-COMMAND-HOTFIX**, NexusCharacters **PRE35-SI1-OPT3**, monnaie Indivis, intégration CapSkills/Puffish. Nexus et le HUD fournis ne sont pas modifiés.

## 1. Remplacer les trois fichiers

Arrêter le serveur et sauvegarder le monde complet, les données EasyNPC/Nexus et les trois anciennes archives. La sauvegarde doit conserver les profils Nexus et les données de stockage du monde, pas seulement les datapacks.

| Fichier livré | Destination | Action |
|---|---|---|
| `capitale_core_1.5.7_PQ04_PQ05_R1_20261109.zip` | `monde/datapacks/` | Remplace le core HF1 fourni ; archive complète avec `pack.mcmeta` à la racine. |
| `hc_quetes_FUSION_C1_PQ04_PQ05_R1_20261109.zip` | `monde/datapacks/` | Remplace le pack `hc_quetes` fusion C1/PQ03 ; toutes ses autres quêtes sont conservées. |
| `haute-capitale-quetes-PQ04-PQ05-R1-1.21.11.jar` | `mods/` du serveur **et de chaque client** | Remplace le JAR Haute Capitale Quêtes HF1 fourni. Même ID de mod, aucune extension séparée à ajouter. |

Une seule copie de chaque datapack et du mod de quêtes doit rester active. Les deux ZIP de datapacks peuvent être installés directement : ne pas placer l'archive globale d'installation dans `datapacks/`. Si l'installation actuelle utilise des dossiers décompressés, remplacer entièrement ces dossiers par le contenu des ZIP correspondants.

Redémarrer le serveur et les clients Minecraft. Un simple `/reload` ne charge pas un nouveau JAR. Les commandes et réglages des autres PNJ restent ceux de l'installation actuelle.

## 2. Lier les quatre PNJ existants

Avec un administrateur, avant de lancer les escortes, se placer successivement à moins de quatre blocs de chaque **PNJ public**, en veillant à n'avoir qu'un seul EasyNPC dans ce rayon, puis exécuter :

| Position de l'administrateur | Commande |
|---|---|
| Près de Roch, au départ de son trajet | `/function capitale:pq45/liaison/roch` |
| Près de Colin, **au poste inférieur**, après la descente réelle | `/function capitale:pq45/liaison/colin` |
| Près de l'aubergiste | `/function capitale:pq45/liaison/aubergiste` |
| Près du magistrat des Profondeurs | `/function capitale:pq45/liaison/magistrat` |

Ces liaisons mémorisent les sources, sans effacer leurs actions ou leur apparence. L'auto-détection reste disponible pour les PNJ déjà reconnus par leurs tags ou commandes. Les liaisons explicites lèvent les ambiguïtés, notamment pour l'aubergiste et le magistrat. Un changement de liaison est refusé si une scène PQ04/PQ05 est en cours ; effectuer cette préparation avant les tests joueurs.

## 3. Mémoriser les parcours actuels

Les **39 repères déjà placés** restent utilisés : Roch A–M et Colin A–Z. Les fonctions historiques `.../waypoints/set_<lettre>_here` et leurs outils de debug sont conservés.

Charger les tronçons du parcours en s'y déplaçant, puis lancer autant que nécessaire :

```mcfunction
/function capitale:pq45/admin/preparer_parcours
/function capitale:pq45/admin/diagnostic_points
```

La mémorisation est cumulative. Elle lit les markers présents dans les chunks chargés ; elle ne crée ni ne déplace aucun repère. Le diagnostic doit annoncer **parcours complet** pour Roch et Colin avant la recette. Un tag de waypoint dupliqué provoque une erreur explicite, sans choisir arbitrairement un point.

Après modification volontaire d'un waypoint, refaire cette mémorisation. Le changement d'une position déjà mémorisée est refusé pendant une scène active. Pour suspendre la scène d'un personnage, exécuter `indivispq45 suspend` **en tant que ce joueur** depuis une source administratrice ; sa progression reste conservée.

Diagnostic d'un personnage actif :

```mcfunction
/function capitale:pq45/admin/diagnostic
```

Pour l'aubergiste et le magistrat, chaque nouvelle conversation repart de la position actuelle du PNJ public ; déplacer ultérieurement l'aubergiste n'impose pas une position de caméra figée dans la configuration.

## 4. Personnages déjà avancés

La migration est automatique à l'interaction ou à la reprise d'une escorte. Elle conserve les états canoniques, la caisse déjà acceptée ou livrée, la chambre payée et les rangs existants. Un résident ou citoyen ne paie pas une seconde inscription ; son rang supérieur est préservé. Les réputations historiques ne sont pas corrigées rétroactivement.

Les anciens états d'escorte ne stockaient pas une position fiable par propriétaire : à la première migration, la reprise utilise le waypoint existant le plus proche, sans téléporter un PNJ public. Ensuite, la position exacte de chaque scène est sauvegardée. À H, un ancien refus non enregistré par personnage ne peut pas être reconstitué avec certitude ; une caisse acceptée reste protégée par son état existant et ne sera pas redonnée.

## 5. Retour à l'installation précédente

Arrêter le serveur. Restaurer ensemble les trois fichiers précédents et, pour retrouver exactement les états d'avant recette, la sauvegarde du monde et des profils Nexus correspondante. Les nouveaux champs sont ajoutés aux données de personnage ; aucune conversion destructive de sauvegarde n'est effectuée.

## Compatibilité raciale

L'API PRE35-SI1-OPT3 disponible expose `human`, `dwarf`, `wood_elf`, `high_elf`, `nordic` et `villager`. Elle ne déclare pas d'ID Orc persistant : les variantes Orc ne sont donc pas activées. Une valeur inconnue reçoit le texte commun ; `villager` n'est pas assimilé à un Orc. Les prix et les accès restent indépendants de la race.

## Vérifications encore à faire sur le serveur Indivis

Vérifier les obstacles réels, les deux ascenseurs, les cadrages et l'adéquation des commentaires à D/H/X. Contrôler le rendu du journal/HUD et les FPS avec deux vrais clients. Les bancs fournis utilisent un monde plat et un client de protocole sans rendu ; ils ne remplacent pas cette recette visuelle.
