# Recette reproductible — PQ04/PQ05-R1

## Préparation

Utiliser un **personnage Nexus de test distinct**, avec rang inférieur à 20 pour tester les frais. Les commandes suivantes réinitialisent ses états et décisions PQ04/PQ05. Elles requièrent OP et le tag de test ; elles ne téléportent ni joueur ni PNJ et ne modifient pas la monnaie ou le rang.

```mcfunction
/tag @s add indivis_pq45_test
```

Les liaisons et les 39 repères doivent avoir été préparés selon le guide d'installation. Les anciennes commandes de pose des waypoints restent valables.

| Situation | Préparation du personnage | Position à rejoindre | Vérification |
|---|---|---|---|
| Première rencontre | `/function capitale:pq45/test/roch` | Roch public, point A | Quatre choix ; « Ça se voit » ouvre trois réponses ; assurance sans malus. |
| Avant H de Roch | `/function capitale:pq45/test/roch_h` | Point G de Roch | Attendre la copie privée puis lui parler et reprendre ; caisse proposée à H. Tester les quatre choix séparément. |
| Après l'ascenseur | `/function capitale:pq45/test/colin` | Colin public, poste inférieur A | Pas de Roch en bas ; pas de dialogue de caisse si aucun item accepté/possédé. |
| Avant D de Colin | `/function capitale:pq45/test/colin_d` | Point C de Colin | Reprendre la marche ; arrêt et conversation au D, questions facultatives puis reprise. |
| Avant H de Colin | `/function capitale:pq45/test/colin_h` | Point G de Colin | Même contrôle au H, embranchement sur la réputation des habitants. |
| Arrivée sur la place | `/function capitale:pq45/test/place` | Point Z de Colin | Une conversation de conclusion suffit ; objectif aubergiste, pas de bonus automatique +5. |
| Début PQ05 | `/function capitale:pq45/test/pq05` | Aubergiste | La chambre est proposée immédiatement, sans visite préalable au magistrat. |

Les points sont les markers réels. Pour rejoindre G de Roch avec le personnage de test, par exemple :

```mcfunction
/execute at @e[type=minecraft:marker,tag=wp_roch_profondeurs_g,limit=1] run tp @s ~ ~ ~
```

Cette commande de téléportation concerne uniquement le joueur de test. Vérifier l'unicité des repères au préalable. Les déplacements de l'escorte restent assurés par la navigation EasyNPC.

## Économie et décisions

Sur le personnage jetable uniquement, préparer une quantité précise de monnaie :

```mcfunction
/clear @s capitale_currency:martin_dor
/give @s capitale_currency:martin_dor 19
```

Changer la quantité pour les cas du tableau. Il s'agit des jetons d'inventaire pris en compte par les fonctions historiques, pas d'un prélèvement bancaire nouvellement ajouté.

| Cas | Résultat attendu |
|---|---|
| Auberge : 0 ou 19 MDI | Aucune chambre ni somme retirée ; retour possible. |
| Auberge : 20 ou 21 MDI | Débit exact de 20, chambre reconnue ensuite ; répétition sans nouveau débit. |
| Magistrat avant chambre | Information brève sur l'adresse ; objectif principal toujours aubergiste. |
| Magistrat : 0 ou 99 MDI après chambre | Aucune inscription ni somme retirée ; retour possible. |
| Magistrat : 100 ou 101 MDI | Débit exact de 100 ; rang porté à 20 si inférieur ; PQ05 terminé ; citoyenneté distincte. |
| Déjà rang 20, 30 ou supérieur | Pas de second achat du statut, pas d'abaissement du rang. |
| Critique du tarif ou de l'Empire | Aucun malus de faction ni souvenir négatif. |
| Caisse acceptée à H | Item réel lié au personnage ; aucun gain de réputation à l'acceptation. |
| Deux refus non méprisants de la caisse | Aucun malus. |
| Refus méprisant de la caisse | −1 Gardes des Profondeurs et −1 souvenir Roch, immédiatement et une fois. |
| Remerciement final à Roch | +1 Gardes et +1 souvenir Roch, une fois. |
| Caisse perdue | Pas de dialogue de livraison ni paiement, escorte disponible. Retrouver l'item permet une remise ultérieure, même après PQ04. |
| Livraison effective | Retrait exact de la caisse, 25 Martins, +1 Gardes, +1 souvenir Colin ; bonus/compétence historiques gardés une fois. |
| Inventaire plein à la prise/remise | Transaction différée ; libérer une place puis réessayer. |
| Réaction défendant les habitants | Souvenir Colin +1 ; faction inchangée. |
| Réaction méprisante envers Colin | −1 Gardes et −1 souvenir Colin ; critiques raisonnables à zéro. |
| Remerciement final à Colin | Souvenir +1, faction inchangée ; aucun +5 de conclusion. |

Comparer immédiatement l'affichage de réputation au choix, puis après réouverture et reconnexion. Ne pas rejouer les resets entre deux vérifications d'idempotence : cela réinitialiserait volontairement les protections du personnage de test.

## Lecture, scène et multijoueur

- Lire tous les blocs sans se presser : aucun minuteur ne doit effacer une réplique. Espace/clic fait avancer les blocs sans réponse ; les choix du protagoniste gardent leurs textes.
- À H de Roch et D/H de Colin, vérifier l'arrêt, l'orientation et l'ouverture à proximité ; les questions doivent revenir à la conversation ou à la marche.
- Roch termine en haut et revient par son parcours. Descendre seul, puis parler à Colin en bas.
- Les plans du magistrat utilisent la caméra habituelle ; Colin parle du magistrat présent sur la place, sans imposer la visibilité d'un bâtiment hors champ.
- Deux joueurs lancent Roch simultanément, puis Colin : aucun acteur, marqueur, choix ou récompense du voisin ne doit être visible/utilisable.
- Un compte alterne deux personnages Nexus de races connues et de progressions différentes : comparer scores, souvenirs et répliques. L'API actuelle ne permet pas une vraie sélection Orc persistante ; tester son comportement de repli séparément des races reconnues.
- S'éloigner d'environ vingt blocs, revenir ; fermer une conversation ; se déconnecter à mi-segment et à une pause ; refaire `/reload` ; arrêter et redémarrer. Aucun retour au début de quête ni téléportation sauvage du guide public ne doit se produire.
- Vérifier les « ! » : aubergiste avant location, magistrat après location, offres des autres PNJ préservées.
- Contrôler PQ01/Gautier, PQ02/Léovic et ses 50 Martins systématiques, PQ03/Aurèle, puis MQ03 : retour au capitaine Althéon et aux Archives toujours accessible.

## Reproduire les bancs automatiques

Depuis les sources livrées, avec Python 3 et Java 21, placer les trois archives d'entrée dans `upload/`, les dépendances listées dans `AUDIT_DEPENDANCES_PQ04_PQ05_R1.md` dans `tools/pq0405/dependencies/`, puis :

```bash
python tools/pq0405/prepare_runtime.py
python tools/pq02/bootstrap_hf9.py
python tools/pq0405/build.py
python tools/pq0405/validate.py
python tools/pq0405/run_protocol.py
python tools/pq0405/run_native.py
python tools/pq0405/run_restart.py
python tools/pq0405/package_release.py
```

Le bootstrap génère le JAR intermédiaire Fabric, sans jouer une quête. Le banc natif utilise un monde **jetable** dans `tools/pq02/runtime_hf9/pq45_native/`, sur `127.0.0.1:25579`, et le réinitialise à chaque lancement. Le banc de redémarrage doit suivre le banc natif : il rouvre le même monde sans recréer les PNJ publics ni les markers. Les simulations de clients ne constituent pas des essais graphiques ni des mesures de FPS.

Après la recette, enlever le tag de test : `/tag @s remove indivis_pq45_test`.
