# Dialogues exhaustifs — PQ04/PQ05-R1

109 blocs, 94 choix. Les textes principaux proviennent du cahier des charges fourni. Les identifiants de blocs sont ceux de `indivis_pq45_graph.json` embarqué dans le JAR. « Suite » signifie une avance demandée par le lecteur, sans minuterie.

Les menus sans réplique reprennent le dernier bloc du même interlocuteur. Les messages techniques courts de fonds/inventaire insuffisants et les rappels après quête sont signalés par leur identifiant. `a_inventory` et `m_inventory` sont des réserves techniques non utilisées par les transactions actuelles.

| Bloc | PNJ | Répliques dans l’ordre | Réponses → cible [condition] / effet | Suite |
|---|---|---|---|---|
| r_intro | roch | Hé, vous là ! Vous venez du Cœur ? / Vous avez l'air de chercher votre chemin. C'est votre première visite dans les Profondeurs ? | Oui, je viens d'arriver dans la capitale. → r_i1 / 0 ; On m'a conseillé de chercher un logement ici. → r_i2 / 0 ; Ça se voit tant que ça ? → r_i3 / 0 ; Je sais très bien où je vais. → r_i4 / 0 | Fermeture disponible |
| r_i1 | roch | Alors bienvenue. Vous constaterez vite que la ville ne s'arrête pas aux beaux quartiers. Et vous n'avez encore rien vu des Profondeurs. | — | r_seek |
| r_i2 | roch | On vous a bien renseigné. Les loyers sont généralement plus abordables qu'en haut, même si le confort n'est pas toujours au rendez-vous. | — | r_seek |
| r_i4 | roch | Ah, parfait ! Vous allez pouvoir m'indiquer le chemin, alors. Ça me changera. | — | r_seek |
| r_i3 | roch | Disons que vous n'êtes pas le premier à sortir de cet ascenseur avec l'air de chercher où l'on a bien pu mettre le reste de la ville. | Vous devez en voir passer beaucoup, des gens perdus. → r_j1 / 0 ; Je suppose que je ne suis pas très discret. → r_j2 / 0 ; Et cela vous amuse ? → r_j3 / 0 | Fermeture disponible |
| r_j1 | roch | Plus que vous ne l'imaginez. Certains finissent même par retrouver leur chemin. | — | r_seek |
| r_j2 | roch | Pas particulièrement, non. Mais rassurez-vous, j'en ai vu de bien pires. | — | r_seek |
| r_j3 | roch | Un peu, je l'admets. Les journées seraient longues si l'on devait rester sérieux à chaque instant. | — | r_seek |
| r_seek | roch | Bon, puisque vous êtes là, autant vous éviter quelques détours. Vous cherchez quelque chose en particulier ? | Un endroit où me loger. → r_s1 / 0 ; Je voudrais surtout découvrir les Profondeurs. → r_s2 / 0 ; Je dois encore me renseigner sur la ville. → r_s3 / 0 | Fermeture disponible |
| r_s1 | roch | Alors vous êtes au bon endroit. Enfin, pas encore tout à fait, mais nous allons arranger ça. | — | r_offer |
| r_s2 | roch | Vous aurez de quoi faire. Mais autant commencer par un endroit où vous pourrez poser vos affaires. | — | r_offer |
| r_s3 | roch | Dans ce cas, je peux au moins vous éviter de passer la journée à chercher le bon ascenseur. | — | r_offer |
| r_offer | roch | Un collègue tient le poste inférieur. Il connaît mieux que moi les établissements où l'on accueille les nouveaux arrivants. / Je dois justement me rendre à l'ascenseur qui y mène. Je vais vous montrer le chemin. | Très bien, je vous suis. → r_start / 0 ; J'aimerais d'abord vous poser quelques questions. → r_questions / 0 | Fermeture disponible |
| r_questions | roch | Menu : dernier bloc conservé | Pourquoi appelle-t-on cet endroit les Profondeurs ? → r_q1 / 0 ; Vous travaillez ici depuis longtemps ? → r_q2 / 0 ; Les Profondeurs sont-elles dangereuses ? → r_q3 / 0 ; Pourquoi les logements sont-ils moins chers ici ? → r_q4 / 0 ; Je vous suis. → r_start / 0 | Fermeture disponible |
| r_q1 | roch | Parce que les quartiers ont été aménagés à différents niveaux, et qu'on descend rarement ici pour admirer le paysage. / Vous êtes dans les parties basses de la capitale. Et il y a encore plusieurs niveaux sous nos pieds. | — | r_questions |
| r_q2 | roch | Assez pour connaître les passages les plus fréquentés et les endroits qui réclament un peu plus d'attention. / Pas assez pour prétendre connaître chaque recoin de la ville. Je laisserai ce privilège aux cartographes. | — | r_questions |
| r_q3 | roch | Il y a des endroits que je vous déconseillerais, oui. Mais ce n'est pas une raison pour regarder chaque passant comme un coupe-bourse. / Restez sur les voies publiques, et prenez le temps de vous familiariser avec les lieux. | — | r_questions |
| r_q4 | roch | Le manque de lumière, l'humidité dans certains secteurs, les accès parfois moins pratiques... Ça compte quand on cherche un endroit où vivre. / Mais tout dépend de l'endroit. Les Profondeurs sont suffisamment grandes pour qu'on évite de les juger d'un seul regard. | — | r_questions |
| r_start | roch | Bien. Restez à proximité, je vais vous montrer le chemin. | — | event:roch_start |
| r_walk | roch | Vous verrez, on se fait assez vite aux passages d'ici. Le plus difficile, au début, c'est de savoir quel ascenseur mène où. / J'ai déjà vu des gens passer plus de temps à chercher le bon étage qu'à rejoindre leur destination. | — | Fermeture disponible |
| r_crate | roch | À propos, puisque vous allez descendre, je pourrais vous demander un petit service. / J'ai une caisse destinée au poste inférieur. Colin Férand doit la réceptionner, et vous passerez justement devant lui. / Si vous acceptez de la lui remettre, je m'assurerai que le service soit rémunéré. | Je peux vous la porter. → r_box1 / Item de caisse réel, état en cours ; réputation 0 ; Je préfère éviter. → r_box2 / Refus, effet 0 ; Vous ne pouvez pas vous en charger ? → r_box3 / Refus interrogatif, effet 0 ; Vous êtes payé pour ça, débrouillez-vous. → r_box4 / −1 Gardes et −1 Roch, une fois | Fermeture disponible |
| r_box1 | roch | Parfait. Tenez, prenez-la. Vous n'aurez qu'à la remettre à Colin lorsque vous arriverez en bas. Il vous réglera pour le service. | — | event:resume |
| r_box2 | roch | Aucun problème. Je la ferai descendre autrement. Continuons. | — | event:resume |
| r_box3 | roch | Si, mais j'ai aussi un poste à tenir. C'était une proposition, pas un ordre. | — | event:resume |
| r_box4 | roch | Ah, voilà qui donne envie de demander de l'aide. Très bien, je m'en chargerai autrement. | — | event:resume |
| r_final | roch | Nous y voilà. Cet ascenseur vous conduira au poste inférieur. / Vous trouverez Colin Férand près de la sortie. Dites-lui que vous cherchez à vous loger, il pourra vous conduire plus loin. | Merci de m'avoir accompagné. C'est aimable à vous. → r_bye1 / +1 Gardes et +1 Roch, une fois ; Très bien. Je vais descendre. → r_bye2 / 0 ; Vous auriez pu m'accompagner jusqu'en bas. → r_bye3 / 0 | Fermeture disponible |
| r_bye1 | roch | Je vous en prie. Vous verrez, on n'est pas tous aussi désagréables qu'on le raconte. | — | event:roch_end |
| r_bye2 | roch | Allez-y. Bonne continuation. | — | event:roch_end |
| r_bye3 | roch | Et abandonner mon poste pour vous tenir la main ? Vous devriez vous en sortir. | — | event:roch_end |
| c_intro | colin | Bonjour. Vous venez du niveau supérieur, je suppose ? / Vous cherchez quelque chose, ou vous avez simplement décidé de descendre jusqu'ici pour voir ce qu'il y avait plus bas ? | Roch Vallet m'a conseillé de venir vous voir. Je cherche un logement. → c_i1 / 0 ; Je viens d'arriver dans la capitale. Je cherche encore à me repérer. → c_i2 / 0 ; On m'a dit que vous pourriez me conduire jusqu'à une auberge. → c_i3 / 0 ; Vous posez toujours autant de questions aux passants ? → c_i4 / 0 | Fermeture disponible |
| c_i1 | colin | Ah, Roch vous a envoyé. Alors vous êtes au bon endroit. Enfin, pour obtenir des renseignements, du moins. | — | c_offer |
| c_i2 | colin | Je vois. Vous avez déjà trouvé le bon ascenseur, c'est un début. | — | c_offer |
| c_i3 | colin | C'est possible, oui. Encore faut-il que vous acceptiez de marcher un peu. | — | c_offer |
| c_i4 | colin | Seulement à ceux qui viennent me trouver pendant mon service. Une vieille habitude, paraît-il. | — | c_offer |
| c_delivery | colin | Ah, parfait. Voilà qui nous évite un trajet supplémentaire. / Tenez, vingt-cinq Martins d'Or. C'est ce qui était prévu pour la livraison. | — | event:colin_context |
| c_offer | colin | Bon, revenons à ce qui vous amène ici. Vous cherchez un endroit où vous loger, c'est bien ça ? / Je connais une auberge qui accueille régulièrement les nouveaux arrivants. Ce n'est pas la porte à côté, mais je peux vous y conduire. | Roch m'a demandé de vous remettre une caisse. → c_delivery [crate] / Caisse possédée/acceptée : retrait, +25 MDI, +1 Gardes, +1 Colin ; bonus/compétence historiques une fois ; Très bien, je vous suis. → c_start / 0 ; J'aimerais vous poser quelques questions avant. → c_questions / 0 ; Pourquoi cette auberge en particulier ? → c_why / 0 | Fermeture disponible |
| c_why | colin | Parce que je sais où elle se trouve, déjà. C'est un avantage appréciable quand on doit servir de guide. / Plus sérieusement, c'est un établissement où l'on peut trouver une chambre sans trop de complications. Pour une première nuit, ce sera un bon point de départ. | — | c_offer |
| c_start | colin | Alors allons-y. Essayez de ne pas trop vous éloigner, les passages ne sont pas toujours évidents à reconnaître. | — | event:colin_start |
| c_questions | colin | Menu : dernier bloc conservé | Vous avez toujours travaillé ici ? → c_q1 / 0 ; Les gardes du Cœur viennent-ils parfois ici ? → c_q2 / 0 ; Vous appréciez votre travail ? → c_q3 / 0 ; Pourquoi êtes-vous aussi serviable avec les nouveaux arrivants ? → c_q4 / 0 ; Et pour devenir résident ? → c_residence / 0 ; Je manque d'argent pour le moment. → c_poor / 0 ; Que raconte-t-on sur les Profondeurs ? → c_rumours / 0 ; Roch m'a demandé de vous remettre une caisse. → c_delivery [crate] / Caisse possédée/acceptée : retrait, +25 MDI, +1 Gardes, +1 Colin ; bonus/compétence historiques une fois ; Je suis prêt. → event:colin_context / 0 | Fermeture disponible |
| c_q1 | colin | Non, pas toujours. Mais cela fait assez longtemps pour que je connaisse les habitudes du quartier. Et pour que les habitants connaissent les miennes, malheureusement. | — | c_questions |
| c_q2 | colin | À l'occasion. Nous avons chacun nos affectations, même s'il nous arrive de travailler ensemble. Cela dépend des circonstances. | — | c_questions |
| c_q3 | colin | Certains jours plus que d'autres. Mais il faut bien que quelqu'un s'en charge. Et je crois encore que nous pouvons être utiles, malgré ce qu'on entend parfois. | — | c_questions |
| c_q4 | colin | Parce qu'il vaut mieux vous indiquer où dormir maintenant que vous retrouver à errer dans les passages en pleine nuit. Et puis, cela fait aussi partie de notre travail. | — | c_questions |
| c_residence | colin | Il faudra faire enregistrer votre situation auprès du magistrat. / Mais inutile d'aller le voir avant même d'avoir trouvé où loger. L'aubergiste pourra d'abord vous renseigner sur les chambres et les justificatifs nécessaires. | — | c_questions |
| c_poor | colin | Dans ce cas, commencez par régler le plus urgent. Je doute que vous soyez le premier nouvel arrivant à devoir surveiller sa bourse. / Pour les frais administratifs, mieux vaut demander directement au magistrat ce qui peut attendre. | — | c_questions |
| c_central | colin | Vous entendrez vite que les Profondeurs ne sont pas exactement réputées pour leur tranquillité. / Surtout près du centre. Entre les machineries et le passage incessant, il y a des jours où l'on s'entend à peine penser. | Les machines fonctionnent en permanence ? → c_machines / 0 ; Pourquoi les habitants restent-ils ici ? → c_inhabitants / 0 ; À propos des Profondeurs… → c_questions / 0 ; Nous pouvons continuer. → event:resume / 0 | Fermeture disponible |
| c_machines | colin | Pour certaines, oui. Et croyez-moi, quand on habite à proximité, on finit par connaître leur bruit aussi bien que sa propre voix. | — | c_central |
| c_inhabitants | colin | Parce que tout le monde n'a pas les moyens de choisir où vivre. / Et puis, malgré les désagréments, certains y ont leurs habitudes, leur travail, leurs proches. On ne quitte pas tout ça si facilement. | — | c_central |
| c_bridges | colin | Vous remarquerez que les Profondeurs changent beaucoup d'un endroit à l'autre. / Certains passages sont si étroits qu'on peine à s'y croiser, tandis qu'ailleurs, on trouve des commerces, des habitations plus convenables et même quelques coins où il fait bon s'arrêter. | Pourtant, les habitants restent plutôt modestes ? → c_modest / 0 ; À propos des Profondeurs… → c_questions / 0 ; Nous pouvons continuer. → event:resume / 0 | Fermeture disponible |
| c_modest | colin | Pour la plupart, oui. Mais il y a une différence entre vivre modestement et manquer de tout. / C'est une distinction que ceux d'en haut oublient parfois. | — | c_bridges |
| c_rumours | colin | Vous entendrez sûrement toutes sortes d'histoires sur les Profondeurs, surtout si vous remontez dans les quartiers supérieurs. / Je vous conseillerais de ne pas prendre tout ce qu'on raconte pour argent comptant. | Les Profondeurs ont si mauvaise réputation ? → c_reputation / 0 | Fermeture disponible |
| c_reputation | colin | Ça dépend de qui vous interrogez. Certains vous parleront de pauvreté, d'autres de criminalité. Et quelques-uns ne sont probablement jamais descendus jusqu'ici. / Il y a des problèmes, je ne vais pas vous raconter le contraire. Mais il y a surtout des gens qui vivent et travaillent ici. | Il serait injuste de juger tout un quartier sur quelques histoires. → c_v1 [view_undecided] / +1 Colin ; faction 0 ; Il doit bien y avoir une part de vérité dans ces histoires. → c_v2 [view_undecided] / 0 ; Les quartiers pauvres attirent forcément les ennuis. → c_v3 [view_undecided] / 0 ; Vous devriez plutôt faire votre travail que défendre ces gens. → c_v4 [view_undecided] / −1 Gardes et −1 Colin, une fois ; Revenons à nos autres questions. → c_questions [view_decided] / 0 | Fermeture disponible |
| c_v1 | colin | Nous sommes d'accord. C'est déjà assez compliqué de juger une personne quand on la connaît. Alors tout un quartier... | — | c_questions |
| c_v2 | colin | Bien sûr. Seulement, il faut savoir faire la différence entre un problème réel et une réputation qui finit par se suffire à elle-même. | — | c_questions |
| c_v3 | colin | La pauvreté peut en créer, oui. Ça ne fait pas de chaque habitant un fauteur de troubles. | — | c_questions |
| c_v4 | colin | Mon travail consiste notamment à protéger ceux qui vivent ici. Il semblerait que nous n'en ayons pas la même conception. | — | c_questions |
| c_outer | colin | Vous voyez, on respire déjà un peu mieux par ici. / On entend moins les machines, les passages sont plus dégagés... Ce sont de petites différences, mais quand on vit quelque part, elles comptent. | Vous préféreriez vivre ici ? → c_prefer / 0 ; Nous pouvons continuer. → event:resume / 0 ; J'ai une autre question. → c_questions / 0 | Fermeture disponible |
| c_prefer | colin | Si j'avais le choix entre dormir au-dessus d'une machinerie et trouver un peu de calme, je ne réfléchirais pas longtemps. / Mais ne croyez pas que tout le monde ici mène une vie confortable pour autant. | — | c_outer |
| c_final | colin | Nous y voilà. C'est l'auberge dont je vous parlais. / Vous pourrez y trouver une chambre et prendre quelques renseignements auprès de l'aubergiste. / Le magistrat siège aussi sur cette place. / Si vous comptez vous installer dans la capitale, vous aurez affaire à lui. Mais commencez par régler votre hébergement, cela vous évitera des démarches inutiles. | Merci de m'avoir accompagné. Vous m'avez été d'une grande aide. → c_bye1 / +1 Colin ; faction 0 ; Très bien. Je vais me renseigner. → c_bye2 / 0 ; Je ne pensais pas que les Profondeurs étaient aussi étendues. → c_bye3 / 0 ; Vous auriez pu m'indiquer le chemin sans me faire marcher tout ce temps. → c_bye4 / 0 ; J'ai encore une question. → c_questions / 0 | Fermeture disponible |
| c_bye1 | colin | Je vous en prie. J'espère que vous trouverez ce qu'il vous faut. | — | event:colin_end |
| c_bye2 | colin | Parfait. Vous savez où aller maintenant. | — | event:colin_end |
| c_bye3 | colin | Et vous n'en avez vu qu'une partie. Vous aurez l'occasion de découvrir le reste. | — | event:colin_end |
| c_bye4 | colin | Sans doute. Mais au moins, maintenant, vous saurez le retrouver. | — | event:colin_end |
| r_travel | roch | Menu : dernier bloc conservé | Je vous suis. → event:resume / 0 ; J'ai une question. → r_travel_questions / 0 | Fermeture disponible |
| r_travel_questions | roch | Menu : dernier bloc conservé | Pourquoi appelle-t-on cet endroit les Profondeurs ? → r_tq1 / 0 ; Vous travaillez ici depuis longtemps ? → r_tq2 / 0 ; Les Profondeurs sont-elles dangereuses ? → r_tq3 / 0 ; Pourquoi les logements sont-ils moins chers ici ? → r_tq4 / 0 ; Reprenons. → event:resume / 0 | Fermeture disponible |
| r_tq1 | roch | Parce que les quartiers ont été aménagés à différents niveaux, et qu'on descend rarement ici pour admirer le paysage. / Vous êtes dans les parties basses de la capitale. Et il y a encore plusieurs niveaux sous nos pieds. | — | r_travel_questions |
| r_tq2 | roch | Assez pour connaître les passages les plus fréquentés et les endroits qui réclament un peu plus d'attention. / Pas assez pour prétendre connaître chaque recoin de la ville. Je laisserai ce privilège aux cartographes. | — | r_travel_questions |
| r_tq3 | roch | Il y a des endroits que je vous déconseillerais, oui. Mais ce n'est pas une raison pour regarder chaque passant comme un coupe-bourse. / Restez sur les voies publiques, et prenez le temps de vous familiariser avec les lieux. | — | r_travel_questions |
| r_tq4 | roch | Le manque de lumière, l'humidité dans certains secteurs, les accès parfois moins pratiques... Ça compte quand on cherche un endroit où vivre. / Mais tout dépend de l'endroit. Les Profondeurs sont suffisamment grandes pour qu'on évite de les juger d'un seul regard. | — | r_travel_questions |
| c_travel | colin | Menu : dernier bloc conservé | Je vous suis. → event:resume / 0 ; J'ai une question. → c_questions / 0 ; Roch m'a demandé de vous remettre une caisse. → c_delivery [crate] / Caisse possédée/acceptée : retrait, +25 MDI, +1 Gardes, +1 Colin ; bonus/compétence historiques une fois | Fermeture disponible |
| a_intro | aubergiste | Bonjour. Vous cherchez une chambre ? | Colin Férand m'a conseillé de venir ici. → a_i1 / 0 ; Oui. Je viens d'arriver dans la capitale. → a_i2 / 0 ; Cela dépend de vos tarifs. → a_i3 / 0 ; Je cherche surtout à m'installer dans les Profondeurs. → a_i4 / 0 | Fermeture disponible |
| a_i1 | aubergiste | Ah, Colin. Il nous envoie régulièrement les nouveaux arrivants. Au moins, il sait qu'ils ne repartiront pas sans avoir trouvé quelqu'un à qui parler. | — | a_offer |
| a_i2 | aubergiste | Alors vous devez avoir fait du chemin. Si c'est un endroit où dormir qu'il vous faut, nous devrions pouvoir nous arranger. | — | a_offer |
| a_i3 | aubergiste | Voilà une question raisonnable. Mieux vaut savoir ce qu'on peut se permettre avant de prendre ses aises. | — | a_offer |
| a_i4 | aubergiste | Alors il vous faudra une adresse à déclarer. Je peux déjà vous proposer un hébergement. Pour les formalités, c'est le magistrat qui s'en charge. | — | a_offer |
| a_offer | aubergiste | Une chambre simple vous coûtera vingt Martins d'Or. Rien de luxueux, mais vous aurez de quoi vous reposer. / Et si vous comptez rester dans la capitale, je pourrai attester que vous êtes hébergé ici. Cela vous servira auprès du magistrat. | — | a_rent |
| a_rent | aubergiste | Alors, nous faisons affaire ? | Je prends une chambre. Voici vingt Martins d'Or. → a_paid / −20 MDI si présents ; chambre 1 ; PQ05=90 ; sinon aucun débit ; Vingt Martins ? C'est un peu cher. → a_cost / 0 ; Je n'ai pas assez d'argent pour le moment. → a_later / 0 ; Pourquoi faut-il déclarer une adresse ? → a_q1 / 0 ; Une chambre d'auberge suffit vraiment ? → a_q2 / 0 ; Et si je trouve un autre logement plus tard ? → a_q3 / 0 | Fermeture disponible |
| a_q1 | aubergiste | L'administration aime savoir où retrouver les gens. Et si vous voulez être reconnu comme résident, il faut bien commencer quelque part. / Ce n'est pas moi qui décide des règlements. Mais je peux au moins vous éviter de vous présenter là-bas sans les renseignements nécessaires. | — | a_rent |
| a_q2 | aubergiste | Pour commencer les démarches, oui. Vous n'allez tout de même pas acheter une maison dès votre premier jour. / Les nouveaux arrivants ont besoin d'un endroit où s'établir, même provisoirement. | — | a_rent |
| a_q3 | aubergiste | Alors vous pourrez faire modifier votre adresse. L'important, c'est que le registre sache où vous joindre. | — | a_rent |
| a_cost | aubergiste | Je comprends. Mais les chambres ne s'entretiennent pas toutes seules, et je dois bien faire vivre l'établissement. Je ne vous force pas la main. Vous savez ce que je peux vous proposer. | — | a_rent |
| a_later | aubergiste | Revenez lorsque vous aurez de quoi payer la chambre. | — | event:leave |
| a_paid | aubergiste | Très bien. Je vous ai inscrit sur notre registre. Votre hébergement est désormais déclaré ici. / Pour devenir résident, il vous reste à voir le magistrat. Vous trouverez son bureau de l'autre côté de la place. / Gardez quelques Martins de côté : l'administration n'est pas aussi généreuse qu'elle est pointilleuse. | — | event:leave |
| a_room | aubergiste | Votre chambre est à vous pour la nuit. Pour le reste, retournez voir le magistrat. | — | event:leave |
| m_intro | magistrat | Bonjour. Que puis-je pour vous ? | Je souhaite me faire inscrire comme résident de la capitale. → m_address / 0 | Fermeture disponible |
| m_address | magistrat | Fort bien. Avez-vous une adresse à déclarer ? | Je suis hébergé à l'auberge de la place. → m_ready / 0 | Fermeture disponible |
| m_ready | magistrat | Un établissement que nous connaissons, en effet. Cela suffira pour votre première inscription. / Reste à régler les formalités. Mais avant cela, assurez-vous de bien comprendre ce à quoi vous vous engagez. | — | m_fee |
| m_fee | magistrat | Si vous souhaitez poursuivre, les droits d'inscription s'élèvent à cent Martins d'Or. / Une fois réglés, votre nom sera porté au registre des résidents. | Très bien. Voici la somme. → m_paid / −100 MDI si présents et statut non acquis ; rang min.20 ; PQ05 terminé ; aucune réputation automatique ; Cent Martins ? C'est considérable. → m_cost / 0 ; Voilà donc comment l'Empire traite ceux qui veulent s'installer. → m_empire / 0 ; Je reviendrai lorsque j'aurai l'argent. → m_later / 0 ; Que signifie exactement être résident ? → m_q1 / 0 ; Pourquoi dois-je payer pour être inscrit ? → m_q2 / 0 ; Et si je change d'adresse ? → m_q3 / 0 ; Quelle différence avec la citoyenneté ? → m_q4 / 0 | Fermeture disponible |
| m_q1 | magistrat | Cela signifie que votre présence est reconnue par l'administration de la capitale. Vous disposez d'une adresse déclarée et des droits associés à votre condition. / Mais ne confondez pas résidence et citoyenneté. Ce sont deux statuts distincts. | — | m_fee |
| m_q2 | magistrat | Les registres ne se tiennent pas seuls. Les actes doivent être établis, contrôlés et conservés. / Vous pouvez contester le montant, mais je ne suis pas autorisé à le modifier. | — | m_fee |
| m_q3 | magistrat | Vous devrez en informer l'administration. L'inscription vous concerne personnellement ; l'adresse sert à établir votre situation actuelle. | — | m_fee |
| m_q4 | magistrat | Un résident est reconnu comme établi dans la capitale. Un citoyen bénéficie de droits supplémentaires au sein de l'Empire. / La citoyenneté obéit à une procédure distincte, dont les frais sont actuellement de cinq cents Martins d'Or. | — | m_fee |
| m_cost | magistrat | Pour certains, assurément. Mais le montant est fixé par l'administration, non par mes préférences personnelles. | — | m_fee |
| m_empire | magistrat | Vous êtes libre de juger nos procédures. Je suis chargé de les appliquer, pas de les rendre populaires. | — | m_fee |
| m_later | magistrat | Votre démarche pourra reprendre lorsque vous disposerez de la somme. | — | event:leave |
| m_paid | magistrat | Fort bien. Nous allons procéder. | — | m_registered |
| m_registered | magistrat | Les frais sont acquittés. Voyons cela... / Votre nom est désormais porté au registre impérial, avec votre adresse d'hébergement dans les Profondeurs. / Vous êtes officiellement reconnu comme résident inscrit de la capitale. / Veillez à tenir votre situation à jour. Les registres sont encore utiles lorsque les gens prennent la peine de les respecter. | — | m_citizenship |
| m_citizenship | magistrat | Votre résidence est en règle. Si vous souhaitez obtenir la citoyenneté impériale, il vous faudra entreprendre une autre démarche. / Les droits correspondants s'élèvent à cinq cents Martins d'Or. / Mais rien ne vous oblige à vous en acquitter aujourd'hui. Vous avez déjà de quoi commencer votre installation. | — | event:citizenship |
| m_early | magistrat | Une adresse d’abord. Louez une chambre à l’auberge, puis revenez me voir. | — | event:leave |
| m_done | magistrat | Vos droits de résidence sont consignés. Tâchez de faire honneur à l’adresse que vous avez donnée. | — | event:citizenship |
| m_citizen | magistrat | Votre citoyenneté est déjà portée aux registres. Les Profondeurs vous connaissent au moins assez pour vous laisser répondre de votre nom. | — | event:leave |
| r_post | roch | Allez, bonne continuation. Et prenez le temps de vous repérer avant de vous aventurer trop loin. | — | event:leave |
| c_post | colin | Bon, je vais retourner à mon poste. Bonne installation à vous. Et prenez le temps de découvrir la ville avant de décider ce que vous en pensez. | Roch m'a demandé de vous remettre une caisse. → c_delivery [crate] / Caisse possédée/acceptée : retrait, +25 MDI, +1 Gardes, +1 Colin ; bonus/compétence historiques une fois ; Bonne continuation. → event:leave / 0 | Fermeture disponible |
| r_inventory | roch | Il faut d'abord libérer une place dans votre inventaire. | — | r_crate |
| c_inventory | colin | Il faut d'abord libérer une place dans votre inventaire. | — | c_offer |
| a_inventory | aubergiste | Il faut d'abord libérer une place dans votre inventaire. | — | a_rent |
| m_inventory | magistrat | Il faut d'abord libérer une place dans votre inventaire. | — | m_fee |
| a_funds | aubergiste | Vous ne disposez pas des vingt Martins nécessaires. Revenez lorsque vous aurez la somme. | — | a_rent |
| m_funds | magistrat | Vous ne disposez pas des cent Martins nécessaires. Votre démarche pourra reprendre plus tard. | — | m_fee |

## Conditions de progression

| Groupe | Condition |
|---|---|
| Roch : introduction/questions | PQ04 0/10/20 ; quatre réponses initiales préservées |
| Roch : caisse | PQ04=30, point H, décision non prise ; inventaire avec place si acceptation |
| Roch : conclusion | PQ04=40, haut de l’ascenseur ; aucun Colin invoqué ici |
| Colin : premier échange/départ | PQ04=50/60, poste inférieur |
| Colin : parcours et questions | PQ04=70 ; pauses D/H et commentaire extérieur X |
| Colin : réactions sur les habitants | Choix disponible tant que CAP_P4_CVIEW=0 ; ensuite réponse déjà mémorisée |
| Colin : conclusion | PQ04=90 ; clôture naturelle vers PQ04=100 |
| Livraison | CAP_PROF_CAISSE=1, prime non versée, item exact possédé et associé au personnage ; reste possible après PQ04 |
| Aubergiste | PQ04 terminé ; chambre reconnue si CAP_CHAMBRE_PROF=1 ; aucun double débit |
| Magistrat avant hébergement | Information courte, aucune obligation préalable à l’auberge |
| Inscription | Chambre déclarée, statut non déjà acquis, 100 Martins disponibles |
| Citoyenneté | Résident 20–29, PQ05 terminé ; démarrage du système historique seulement s’il n’a pas déjà commencé |

À la conclusion de Roch, la phrase « Et pensez à lui remettre la caisse… » s’ajoute uniquement si CAP_PROF_CAISSE=1. Colin dit « Le magistrat siège aussi sur cette place. » à la place d’un cadrage imposant de voir le bâtiment.

## Variantes réellement activées

| PNJ | Donnée Nexus | Variante |
|---|---|---|
| "roch:human" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | Les nouveaux venus prennent souvent cet ascenseur. Vous n'êtes pas le premier à hésiter à la sortie. |
| "roch:wood_elf","roch:high_elf" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | On ne croise pas tous les jours un elfe qui découvre ces niveaux. Vous cherchez un logement, vous aussi ? |
| "roch:dwarf" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | Vous cherchez le poste inférieur ? Il est facile de confondre les accès, même quand on connaît les passages souterrains. |
| "roch:nordic" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | Prenez garde aux ascenseurs, ils ne pardonnent pas les mauvais étages. |
| "colin:wood_elf","colin:high_elf" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | Vous verrez, le quartier est moins uniforme qu'il n'y paraît. Il vaut mieux le traverser avant de s'en faire une idée. |
| "colin:dwarf" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | Je vous montrerai les passages plutôt que d'essayer de vous les décrire. Ils se ressemblent parfois plus qu'ils ne le devraient. |
| "colin:nordic" | Personnage actif, réputation ordinaire, pas de priorité personnelle/criminalité | Les habitudes d'ici peuvent surprendre. Prenez simplement le temps de regarder comment on vit. |

La criminalité à partir de 10, le souvenir négatif ou la réputation ≤−40 déclenchent la prudence. Souvenir positif ou réputation ≥10 déclenchent un accueil ouvert. Ces limites viennent de la classification des gardes du core. La race n’est lue qu’ensuite. Le magistrat garde le texte administratif commun.

Les propositions Orc de Roch, Colin et de l’aubergiste restent **non activées** : Nexus PRE35-SI1-OPT3 ne fournit pas d’ID Orc persistant. Un identifiant inconnu reçoit le texte commun, sans être traduit en `villager`. La première phrase nordique affirmant une origine lointaine est retirée ; seul le conseil neutre sur les ascenseurs est retenu. Aucun effet racial sur le prix, la réputation, le rang ou les droits.
